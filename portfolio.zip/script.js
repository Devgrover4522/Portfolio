// script.js

// Contact Form Submission Handler
document.getElementById('contactForm').addEventListener('submit', function (event) {
    event.preventDefault();

    // Get form input values
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Simple validation (additional checks can be added)
    if (name && email && message) {
        alert(`Thank you, ${name}! Your message has been sent successfully.`);
        // Clear the form
        this.reset();
    } else {
        alert('Please fill out all fields before submitting.');
    }
});

// Highlight Active Navigation Link
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', function () {
        document.querySelectorAll('nav a').forEach(nav => nav.classList.remove('underline'));
        this.classList.add('underline');
    });
});
